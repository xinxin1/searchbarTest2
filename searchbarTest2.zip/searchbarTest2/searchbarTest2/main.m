//
//  main.m
//  searchbarTest2
//
//  Created by saman on 16/12/9.
//  Copyright © 2016年 saman. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
