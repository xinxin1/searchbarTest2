//
//  ViewController.m
//  searchbarTest2
//
//  Created by saman on 16/12/9.
//  Copyright © 2016年 saman. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UISearchResultsUpdating,UITableViewDelegate,UITableViewDataSource,UISearchControllerDelegate>

//  搜索结果视图
@property (nonatomic, strong) UITableViewController *searchResultVC;
//  搜索视图
@property (nonatomic, strong) UISearchController *searchVC;

@property (nonatomic, strong) NSArray *dataArray;
@property (nonatomic, strong) NSMutableArray *searchArray;

@property (nonatomic, strong) UITableView *myTable;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor greenColor];
    
    [self createData];
    [self.view addSubview:self.myTable];
    [self createSearchController];
}

- (void)createData{
    self.dataArray = @[@"aaa",@"aab",@"aac",@"aba",@"abc",@"abb",@"acc",
                       @"baa",@"bab",@"bac",@"bba",@"bbc",@"bbb",@"bcc",
                       @"caa",@"cab",@"cac",@"cba",@"cbc",@"cbb",@"ccc",];
}

//  搜索结果视图
- (void)createSearchController{
    
    self.searchResultVC = [[UITableViewController alloc] initWithStyle:UITableViewStylePlain];
    self.searchResultVC.tableView.delegate = self;
    self.searchResultVC.tableView.dataSource = self;
    self.searchResultVC.tableView.frame = self.view.bounds;
    
    self.searchVC = [[UISearchController alloc] initWithSearchResultsController:self.searchResultVC];
    self.searchVC.searchResultsUpdater = self;
    self.searchVC.delegate = self;
    
    //  控制tableview不进行偏移
    self.definesPresentationContext = YES;
    
    self.searchVC.searchBar.frame = CGRectMake(0, 0, self.view.bounds.size.width, 44);
    self.myTable.tableHeaderView = self.searchVC.searchBar;
    self.myTable.tableFooterView = [UIView new];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




#pragma mark - Overied
- (UITableView *)myTable{
    if (!_myTable) {
        _myTable = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _myTable.delegate = self;
        _myTable.dataSource = self;
    }
    return _myTable;
}



#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView == self.myTable) {
        return self.dataArray.count;
    }
    return self.searchArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellId = @"cellId";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    if (tableView == self.myTable) {
        cell.textLabel.text = self.dataArray[indexPath.row];
    }else{
        cell.textLabel.text = self.searchArray[indexPath.row];
    }
    
    return cell;
}


#pragma mark -


#pragma mark - Search Delegate
- (void)updateSearchResultsForSearchController:(UISearchController *)searchController{
    //  搜索框中发生改变，就会调用
    
    //  如果是在搜索状态下
    if (self.searchVC.isActive) {
        //  如果没有创建就进行创建，如果有，清空上次数据，然后遍历获取数据，并展示
        if (self.searchArray == nil) {
            self.searchArray = [NSMutableArray arrayWithCapacity:0];
        }else{
            [self.searchArray removeAllObjects];
            
            for (NSString *str in self.dataArray) {
                NSRange range = [str rangeOfString:searchController.searchBar.text];
                //如果包含这个字符，就添加进数组中
                if (range.location != NSNotFound) {
                    [self.searchArray addObject:str];
                }
            }
        }
        [self.searchResultVC.tableView reloadData];
    }
    
    
}


#pragma mark - UISearchControllerDelegate代理

//测试UISearchController的执行过程

- (void)willPresentSearchController:(UISearchController *)searchController
{
    NSLog(@"willPresentSearchController");
}

- (void)didPresentSearchController:(UISearchController *)searchController
{
    NSLog(@"didPresentSearchController");
}

- (void)willDismissSearchController:(UISearchController *)searchController
{
    NSLog(@"willDismissSearchController");
}

- (void)didDismissSearchController:(UISearchController *)searchController
{
    NSLog(@"didDismissSearchController");
}

- (void)presentSearchController:(UISearchController *)searchController
{
    NSLog(@"presentSearchController");
}



@end
